package com.snhu.sslserver;

import java.security.MessageDigest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class ChecksumController {

    @GetMapping("/checksum")
    public String calculateChecksum() {
        // Static data for checksum calculation
        String data = "Matthew Dunfee";
        
        try {
            // Create a MessageDigest instance for SHA-256 hashing algorithm
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            
            // Compute the hash value of the data
            byte[] hashBytes = digest.digest(data.getBytes());
            
            // Convert the byte array to a hexadecimal string
            StringBuilder hexString = new StringBuilder();
            for (byte hashByte : hashBytes) {
                String hex = Integer.toHexString(0xff & hashByte);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            
            // Return the computed checksum
            return String.format("\"SHA-256\"(%s: %s)",data, hexString.toString());
        } catch (Exception ex) {
            // Handle exceptions
            ex.printStackTrace();
            return "Error calculating checksum";
        }
    }
}